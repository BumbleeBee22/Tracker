<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class dummy extends Model
{
    //
}
