<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class student extends Model
{
    protected $table = 'student';

    protected $fillable = [
    	'bus_id',
    	'regno',
    	'name',
    	'email',
    	'password',
    	'address',
    	'picture',
    	'contact'
    ];

    public function bus()
    {
    	return $this->belongsTo('App\bus');
    }
}
