<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class busdata extends Model
{
    protected $table = 'busdata';

    protected $fillable = [
    	'bus_id',
    	'longitude',
    	'latitude',
    	'pic',
    	'video',
    	'audio',
    ];

    public function bus()
    {
    	return $this->belongsTo('App\bus');
    }
}
