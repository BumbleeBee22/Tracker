<?php

/*
|--------------------------------------------------------------------------
| Routes File
|--------------------------------------------------------------------------
|
| Here is where you will register all of the routes in an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/



Route::group(['middleware' => ['web']], function () {

    Route::get('login', 'Auth\AuthController@getLogin');
    Route::post('login', 'Auth\AuthController@postLogin');
// Route::get('/', function () {
// 	echo "Welcome to demo App";
//     //return view('welcome');
// });


Route::get('/', 'maincontroller@index');
// Route::get('/addstudent', 'maincontroller@addstudent');
// Route::get('/addbusdata', 'maincontroller@addbusdata');
// Route::get('/addmessage', 'maincontroller@addmessage');

    Route::group(['middleware' => ['auth']], function () {
Route::get('/addadmin', 'maincontroller@addadmin');
//    Route::get('/addadmin', 'Usercontroller@addadmin');

// Route::get('/addbus', 'maincontroller@addbus');


// Route::post('save', 'buscontroller@save');
// Route::get('bus', 'buscontroller@index');
// Route::get('addbus', 'buscontroller@create');
// Route::post('bus', 'buscontroller@store'); 
// Route::get('/bus/{id}', 'buscontroller@show');
// Route::get('/bus/{id}/edit', 'buscontroller@edit');
// Route::patch('bus', 'buscontroller@update'); 
// Route::patch('/preferences/{id}',[
//     'as' => 'user.preferences.update',
//     'uses' => 'UserController@update'
// ]);

// Route::patch('bus', [
//   'as' => 'update', 
//   'uses' => 'buscontroller@update'
// ]);

//Route::auth();


Route::resource('bus', 'buscontroller');
Route::resource('student', 'studentcontroller');
Route::resource('busdata', 'busdatacontroller');
Route::resource('message', 'messagecontroller');
Route::resource('user', 'usercontroller');


// Authentication routes...


Route::get('logout', 'Auth\AuthController@getLogout');

// Registration routes...
Route::get('register', 'Auth\AuthController@getRegister');
Route::post('register', 'Auth\AuthController@postRegister');
    });
});

// Route::group(['middleware' => 'web'], function () {
//     Route::auth();

//     Route::get('/home', 'HomeController@index');
// 
//}

//);
