<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use DB;
use App\busdata;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;

class mainController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function __construct() {
        $this->middleware('auth');
    }

    public function index(){

        $busdata = busdata::all();
        //return $busdata;
    	 return view('main.index')->with('busdata', $busdata);
    }
    public function addadmin(){
        return view('main.addadmin');
    }
    
}
