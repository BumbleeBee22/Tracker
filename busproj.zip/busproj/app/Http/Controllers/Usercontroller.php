<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

//use Illuminate\Support\Facades\Crypt;
use DB;
use App\User;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\Hash;

class UserController extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    public function __construct()
    {
        $this->middleware('auth');
    }

    public function index()
    {
        //return view('main.addadmin');
      return '123';


        /*   $users = users::all();
           if (is_null($users)) {
               abort(404);
           }
           return view('message.index',compact('message'));
           //return view('bus.index')->with('buses', $buses);
           //return 'bus controller';
           //return $buses;
       }

       public function show($id){
           //  $busdata = busdata::find($id);
           //  if (is_null($stbusdataudent)) {
           //     abort(404);
           //  }

           // return view('busdata.show',compact('busdata'));
           //return $bus;
           //return 'bus controller';
        */
    }

    public function create()
    {

        //$buses = \DB::table('bus')->lists('number', 'id');
       // return view('message.create');
        //return view('student.create');
    }


    public function store(Request $request)
    {
        // echo "<pre>";
        // print_r($request->all());


        //echo $up->getClientOriginalName();
        //echo $up->getMimeType();
        //exit();

        //    $this->validate($request,[
        //        'regno' => 'required',
        //        'name' => 'required',
        //        'email' => 'required|email',
        //        'password' => 'required|min:5',
        //        'picture' => 'mimes:jpeg,bmp,png',
        //        'address' => 'required',
        //        'contact' => 'required|digits:11'
        //     ]);

        // $input=$request->all();
        //    $input['created_at']= carbon::now();

        //    $up=$request->all()['picture'];
        //    $imageName = $request->all()['regno'] . '.' .$up->getClientOriginalExtension();
        //    $destinationPath=base_path().'/public/images/catalog/';
        //    $up->move($destinationPath, $imageName);
        //    $input['picture']='/images/catalog/'.$imageName;

        //    busdata::create($input);
        //    return redirect('busdata');
    }

    public function edit($id)
    {

        $user = user::findorfail($id);
        //return $user;
        //$decrypted = ;
        //return Crypt::decrypt($user->password);
        return view('user.edit')->with('user', $user);

    }

    public function update($id, Request $request)
    {

        $user = user::findorfail($id);
        $input=$request->all();
        $user->name=$input['name'];
        $user->email=$input['email'];
        $user->address=$input['address'];
        $user->contact=$input['contact'];
        $user->password=Hash::make($input['password']);

         $user->save();
        //$bus->fill($request->all());
        //bus::create($input);
        return redirect('/');
    }
}