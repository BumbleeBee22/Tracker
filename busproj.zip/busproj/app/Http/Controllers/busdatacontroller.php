<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Bus;
use App\Student;
use App\busdata;
use Carbon\Carbon;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


use Input;
use Validator;
use Redirect;
use Session;


class busdataController extends Controller
{
   public function index(){
         $busdata = busdata::all();
         if (is_null($busdata)) {
            abort(404);
         }
         //return view('busdata.index',compact('busdata'));


   //	return "hello";
         return view('busdata.index')->with('busdata', $busdata);
        //return 'bus controller';
         //return $buses;
    }

    public function show($id){
         $busdata = busdata::find($id);
         //if (is_null($stbusdataudent)) {
        if (is_null($busdata)) {

            abort(404);
         }

        return view('busdata.show',compact('busdata'));
         //return $bus;
        //return 'bus controller';
    }

    public function create(){

        $buses = \DB::table('bus')->lists('number', 'id');
        return view('busdata.create')->with('buses', $buses);
        //return view('student.create');
    }


    public function store(Request $request){
        // echo "<pre>";
        // print_r($request->all());


        
        //echo $up->getClientOriginalName();
        //echo $up->getMimeType();
        //exit();
    
     //    $this->validate($request,[  
     //        'regno' => 'required',
     //        'name' => 'required',
     //        'email' => 'required|email',
     //        'password' => 'required|min:5',
     //        'picture' => 'mimes:jpeg,bmp,png',
     //        'address' => 'required',
     //        'contact' => 'required|digits:10'
     //     ]);

    	// $input=$request->all();
     //    $input['created_at']= carbon::now();

     //    $up=$request->all()['picture'];
     //    $imageName = $request->all()['regno'] . '.' .$up->getClientOriginalExtension();
     //    $destinationPath=base_path().'/public/images/catalog/';
     //    $up->move($destinationPath, $imageName);
     //    $input['picture']='/images/catalog/'.$imageName;

     //    busdata::create($input);
     //    return redirect('busdata');
    }

    public function edit($id){

        // $student = student::findorfail($id);
        // $buses = \DB::table('bus')->lists('number', 'id');
        // return view('busdata.edit')->with('student', $student)->with('buses', $buses);       
        
    }

    public function update($id, Request $request){

        // $busdata = busdata::findorfail($id);
        // $input=$request->all();
        //  $busdata->fill($input);
        //  $busdata->save();
        // //$bus->fill($request->all());
        // //bus::create($input);
        // return redirect('busdata');
    }
    
}
