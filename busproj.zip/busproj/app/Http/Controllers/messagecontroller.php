<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\message;
use App\Student;
use Carbon\Carbon;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;




class messageController extends Controller
{

    public function __construct() {
        $this->middleware('auth');
    }

   public function index(){
         $message = message::all();
         if (is_null($message)) {
            abort(404);
         }
         return view('message.index',compact('message'));
    }

    public function show($id){
    }

    public function create(){

        //$buses = \DB::table('bus')->lists('number', 'id');
        return view('message.create');
        //return view('student.create');
    }


    public function store(Request $request){

//        $this->validate($request,[
//            'regno' => 'required',
//            'name' => 'required',
//            'email' => 'required|email',
//            'password' => 'required|min:5',
//            'picture' => 'mimes:jpeg,bmp,png',
//            'address' => 'required',
//            'contact' => 'required|digits:11'
//        ]);

        $input=$request->all();

        $input['created_at']= carbon::now();
      //  $input['user_id']= Auth::user()['id'];

//        $up=$request->all()['picture'];
//        $imageName = $request->all()['regno'] . '.' .$up->getClientOriginalExtension();
//        $destinationPath=base_path().'/public/images/catalog/';
//        $up->move($destinationPath, $imageName);
//        $input['picture']='/images/catalog/'.$imageName;

        message::create($input);
        return redirect('message');

    }

    public function edit($id){

    }

    public function update($id, Request $request){

    }
    
}
