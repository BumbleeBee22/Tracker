<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Bus;
use App\Student;
use Carbon\Carbon;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


use Input;
use Validator;
use Redirect;
use Session;


class studentController extends Controller
{
    public function __construct() {
        $this->middleware('auth');
    }
    
   public function index(){
         $students = student::all();
         if (is_null($students)) {
            abort(404);
         }
         return view('student.index',compact('students'));
        
    }

    public function show($id){
         $student = student::find($id);
         if (is_null($student)) {
            abort(404);
         }

        return view('student.show',compact('student'));
        
    }

    public function create(){

        $buses = \DB::table('bus')->lists('number', 'id');
        return view('student.create')->with('buses', $buses);
       
    }


    public function store(Request $request){
         /*echo "<pre>";
         print_r($request->all());
		 exit();
*/

        
        //echo $up->getClientOriginalName();
        //echo $up->getMimeType();
        //exit();
    
        $this->validate($request,[  
            'regno' => 'required',
            'name' => 'required',
            'email' => 'required|email',
            'password' => 'required|min:5',
            'picture' => 'mimes:jpeg,bmp,png',
            'address' => 'required',
            'contact' => 'required'
         ]);

    	$input=$request->all();
		
        $input['created_at']= carbon::now();

        $up=$request->all()['picture'];
        $imageName = $request->all()['regno'] . '.' .$up->getClientOriginalExtension();
        $destinationPath=base_path().'/public/images/catalog/';
        $up->move($destinationPath, $imageName);
        $input['picture']='/images/catalog/'.$imageName;

        student::create($input);
        return redirect('student');
    }

    public function edit($id){

        $student = student::findorfail($id);
        $buses = \DB::table('bus')->lists('number', 'id');
        return view('student.edit')->with('student', $student)->with('buses', $buses);       
        
    }

    public function update($id, Request $request){

        $student = student::findorfail($id);
        $input=$request->all();
         $student->fill($input);
         $student->save();
        //$bus->fill($request->all());
        //bus::create($input);
        return redirect('student');
    }

    public function destroy($id)
    {
        $student = student::findOrFail($id);
        $student->delete();

        return Redirect::route('student.index')->with('message', 'Student deleted.');
    }
    
}
