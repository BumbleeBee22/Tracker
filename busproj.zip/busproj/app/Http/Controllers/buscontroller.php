<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use DB;
use App\Bus;
use Carbon\Carbon;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;


class busController extends Controller
{

   public function __construct() {
        $this->middleware('auth');
    }

    public function index(){
         $buses = bus::all();
         //return $bus;
         if (is_null($buses)) {
            abort(404);
         }
         return view('bus.index',compact('buses'));
         //return view('bus.index')->with('buses', $buses);
        //return 'bus controller';
         //return $buses;
    }

    public function show($id){
         $bus = bus::find($id);
         if (is_null($bus)) {
            abort(404);
         }

        return view('bus.show',compact('bus'));
         //return $bus;
        //return 'bus controller';
    }

    public function create(){

         return view('bus.create');
    }

     public function store(Request $request){

        $this->validate($request,[  
            'number' => 'required',
            'route' => 'required',
            'drivername' => 'required',
            'driverno' => 'required',
            'conductorname' => 'required',
            'condutorno' => 'required'
         ]);
    	$input=$request->all();
        $input['created_at']= carbon::now();
        bus::create($input);
        return redirect('bus');
    }

    public function edit($id){

        $bus = bus::findorfail($id);
        return view('bus.edit',compact('bus'));        
        
    }

    public function update($id, Request $request){

        $bus = bus::findorfail($id);
        $input=$request->all();
         $bus->fill($input);
         $bus->save();
        //$bus->fill($request->all());
        //bus::create($input);
        return redirect('bus');
    }

    public function destroy($id)
    {
        $bus = bus::findorfail($id);
        $bus->delete();
        return redirect('bus');
//        return Redirect::route('bus')->with('message', 'Bus deleted.');
    }


}
