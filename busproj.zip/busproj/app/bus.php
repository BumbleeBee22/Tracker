<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class bus extends Model
{

	protected $table = 'bus';

    protected $fillable = [
    	'number',
    	'route',
    	'drivername',
    	'driverno',
    	'conductorname',
    	'condutorno'
    ];

    public function students()
    {
    	return $this->hasMany('App\student');
    }

    public function busdata()
    {
    	return $this->hasMany('App\busdata');
    }
}
